import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-multiple-books',
  templateUrl: './add-multiple-books.component.html',
  styleUrls: ['./add-multiple-books.component.css']
})
export class AddMultipleBooksComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
