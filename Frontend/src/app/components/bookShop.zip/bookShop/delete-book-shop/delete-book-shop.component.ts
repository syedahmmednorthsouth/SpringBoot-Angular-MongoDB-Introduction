import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-book-shop',
  templateUrl: './delete-book-shop.component.html',
  styleUrls: ['./delete-book-shop.component.css']
})
export class DeleteBookShopComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
